---
title: Mission 1 - IA
weight: 1
---

# Mission 1 : Intelligence Artificielle 

## Introduction 

Le groupe NullVastation a attaqué plusieurs entreprises et met à leur disposition une application pour qu'ils puissent payer une rançon. L'objectif est de corrompre l'IA pour que celle-ci nous donne les données d'une des victimes. 

## Reconaissance 

En arrivant sur l'application on trouve une IA sous forme de chat bot. en discutant avec elle, elle nous demande d'envoyer la rançon vers un portefeuille cryptomonnaie. On doit pouvoir lui faire croire que la transaction a été faite. 

## Exploitation

On essaie dans un premier temps de lui dire que la transaction a bien été faite. Cependant cela est insuffisant et l'IA nous demande un lien vers la transaction.

En lui envoyant un lien vers une transaction de la blockchain le chatbot nous donne une clé poiur déchiffrer les données qui sont dans une archive protégée par mot de passe. 

En ouvrant l'archive on trouve un document qui contient le drapeau. 