---
title: Virtual Machines
weight: 1
bookCollapseSection: true
---

<div class="book-hero">

# Virtual Machines
<center>

<img alt="Corgi hacking the bakery" src="../img/badboy.png"/>
</center>
Cette section comprend tous les writeups que j'ai pu écrire pour des challenges provenant de différentes plateformes : 

- Vulnhub 
- Root-Me
- TryHackMe

## Quelques Writeups 
- [Mr. Robot](./collapsed/mrrobot) : Boot to Root sur un wordpress vulnérable
- [Alice au pays des merveilles](./collapsed/wonderlands) : Énumération et multiples escalades de privilèges
- [RootMe](./collapsed/wonderlands) : Une énumération, un mauvais contrôle des téléchargement et une escalade de privilège
- [Hammer](./collapsed/hammer) : Compromission via une authentification vulnérable
</div>






