---
title: Writeups
weight: 1
bookCollapseSection: true
---

<div class="book-hero">

# Writeups



Dans cette section, vous trouverez quelques write-ups à propos des CTF auxquels j'ai pu participer. 

Les Writeups sont des comptes-rendu, plus ou moins détaillé, des CTFs et divers challenge de sécurité. Ceux-ci permettent de détailler un cheminement, plus ou moins intellectuel, et plus ou moins subtile !

{{% columns %}}
- ## CTF
  - [Root-Me X DGSE](./rootmepro2025/)

- ## Boxes
  - [Mr Robot](./vm/collapsed/mrrobot)
  - [Alice au pays des merveilles](./vm/collapsed/wonderlands)
  - [RootMe](./vm/collapsed/rootme)
  - [Hammer](./vm/collapsed/hammer)
{{% /columns %}}


