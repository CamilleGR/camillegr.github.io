# Articles de blogs 

J'ai eu la chance de pouvoir écrire plusieurs articles de blogs sur des sujets divers et variés. En voici la liste : 

- [Modernisation des applications : Evolution & Enjeux](https://medium.com/leanovia/modernisation-des-syst%C3%A8mes-dinformation-evolution-enjeux-5346cceb4059)
- [Test de charge : Quel outil open source pour générer une forte charge ?](https://medium.com/leanovia/test-de-charge-quel-outil-open-source-pour-g%C3%A9n%C3%A9rer-une-forte-charge-ecfb0fbbad98)
- [Synthetic Monitoring avec Sitespeed.io et Grafana](https://medium.com/leanovia/synthetic-monitoring-avec-sitespeed-io-et-grafana-3a1658737a78 )
- [Tester les performances d’un client web](https://medium.com/leanovia/tests-de-performances-des-applications-web-dd673d30a596 )